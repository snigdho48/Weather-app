const String weatherApiKey = 'bab3ced1d49c66643c13b317c500b2b0';
const String metric = 'metric';
const String imperial = 'imperial';
const String celsius = 'C';
const String fahrenheit = 'F';
const String degree = '\u00B0';
const String iconPrefix = 'https://openweathermap.org/img/wn/';
const String iconSuffix = '@2x.png';
const String ac='https://www.google.com/url?sa=i&url=https%3A%2F%2Fen.wiktionary.org%2Fwiki%2F%25C2%25B0C&psig=AOvVaw1_VKanKn0TwtTT4kwGANuW&ust=1669528172080000&source=images&cd=vfe&ved=0CBAQjRxqFwoTCNiqkJ-Ty_sCFQAAAAAdAAAAABAE';
const String inac='https://www.google.com/url?sa=i&url=https%3A%2F%2Ficon-icons.com%2Ficon%2Ftemperature-fahrenheit%2F151056&psig=AOvVaw047Rs1CAYmyX8BUjGtA6kw&ust=1669528271317000&source=images&cd=vfe&ved=0CBAQjRxqFwoTCLDc1c6Ty_sCFQAAAAAdAAAAABAE';

const cities = [
'Dhaka',
];
