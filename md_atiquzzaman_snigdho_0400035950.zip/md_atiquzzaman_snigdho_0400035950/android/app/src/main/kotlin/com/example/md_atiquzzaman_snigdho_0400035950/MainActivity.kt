package com.example.md_atiquzzaman_snigdho_0400035950

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
